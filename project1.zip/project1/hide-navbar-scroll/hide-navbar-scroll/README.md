# Auto-hiding-bootstrap-navbar
jQuery-based plugin to achieve the effect of a navbar menu hiding and showing automatically when you scroll.
